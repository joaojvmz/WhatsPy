import cv2
import sys
import pyautogui
import pyperclip
import time
import random
import pygame

pyautogui.pause = 2

text = ("""MESSAGE""")
pyautogui.press('win')
pyautogui.write('brave')
pyautogui.press('enter')
time.sleep(2)
pyautogui.hotkey('ctrl','t')
pyperclip.copy('https://web.whatsapp.com/')
pyautogui.hotkey('ctrl', 'v')
pyautogui.press('enter')
time.sleep(10)

x = 1513
y = 155
yy = 185
for i in range(44):
 #enter on the group
 pyautogui.click(x=339, y=383)
 #clicking into the contact
 pyautogui.click(x=x, y=y)
 time.sleep(1)
 pyautogui.click(x=x, y=y)
 time.sleep(random.uniform(1.2, 3.5))
 pyautogui.click(x=x, y=y)
 #the box with option of start a chat appears
 time.sleep(random.uniform(1.2, 2.1))
 pyautogui.click(x=1400, y=yy)
 time.sleep(random.uniform(1.0, 2.8))
 #click on the chat
 pyautogui.click(x=788, y=966)
 time.sleep(random.uniform(2.0, 3.8))
 pyperclip.copy(text)
 pyautogui.hotkey('ctrl','v')
 time.sleep(random.uniform(2.0, 4.0))
 pyautogui.press('enter')
 time.sleep(random.uniform(4.5, 10.3))
 y += 17
 yy += 17
 if i == 39:
  pygame.init()
  pygame.mixer.music.load("beet.mp3")
  pygame.mixer.music.play()
